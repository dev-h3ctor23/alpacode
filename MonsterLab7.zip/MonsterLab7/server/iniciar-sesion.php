<?php
session_start();
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['user']) ? trim($_POST['user']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($username) || empty($password)) {
        header('Location: ../HTML/login.html?error=empty_fields');
        exit;
    }

    $sql = "SELECT id_usuario, nombre_usuario, contrasena, nombre_tipo 
            FROM Usuario 
            WHERE nombre_usuario = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado && $resultado->num_rows === 1) {
        $fila = $resultado->fetch_assoc();

        // Aquí la comparación con password_verify o texto plano.
        // Si usaste password_hash en el registro:
        // if (password_verify($password, $fila['contrasena'])) {
        //     ...
        // }

        if ($password === $fila['contrasena']) {
            // Guardamos el nombre del usuario en sesión
            $_SESSION['nombre_usuario'] = $fila['nombre_usuario'];
            
            // Redirigir a panel
            header('Location: ../HTML/panel-de-padres.html');
            exit;
        } else {
            header('Location: ../HTML/login.html?error=invalid_credentials');
            exit;
        }
    } else {
        header('Location: ../HTML/login.html?error=invalid_credentials');
        exit;
    }

    $stmt->close();
    $conn->close();
} else {
    header('Location: ../HTML/login.html?error=invalid_method');
    exit;
}
?>
